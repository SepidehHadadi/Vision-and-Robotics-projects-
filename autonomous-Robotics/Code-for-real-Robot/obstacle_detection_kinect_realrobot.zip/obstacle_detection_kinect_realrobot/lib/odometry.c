/*!
 * (c) 2006 - 2008 EPFL, Lausanne, Switzerland
 * Thomas Lochmatter
 * Adapted by Nicolas Heiniger for the e-puck
 */

#include <webots/differential_wheels.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "odometry.h"
#include "errno.h"

#define PI 3.14159265358979

// calibration for an accurate odometry
float increments_per_tour = 1000.0; // from e-puck.org
float axis_wheel_ratio = 1.4134;     // from e-puck.org
float wheel_diameter_left = 0.0416;  // from e-puck.org
float wheel_diameter_right = 0.0404; // from e-puck.org
float scaling_factor = 0.976;         // default is 1

void odometry_track_init() {
}

int odometry_track_start(struct sOdometryTrack * ot) {
	return odometry_track_start_pos(ot, wb_differential_wheels_get_left_encoder(), wb_differential_wheels_get_right_encoder());
}

int odometry_track_start_pos(struct sOdometryTrack * ot, int pos_left, int pos_right) {
	ot->result.x = 0;
	ot->result.y = 0;
	ot->result.theta = 0;

	ot->state.pos_left_prev = pos_left;
	ot->state.pos_right_prev = pos_right;

	// Odometry values
	ot->configuration.wheel_distance = axis_wheel_ratio * scaling_factor * (wheel_diameter_left + wheel_diameter_right) / 2;
	ot->configuration.wheel_conversion_left = wheel_diameter_left * scaling_factor * PI / increments_per_tour;
	ot->configuration.wheel_conversion_right = wheel_diameter_right * scaling_factor * PI / increments_per_tour;
	return 1;
}

void odometry_track_step(struct sOdometryTrack * ot) {
	odometry_track_step_pos(ot, wb_differential_wheels_get_left_encoder(), wb_differential_wheels_get_right_encoder());
}

void odometry_track_step_pos(struct sOdometryTrack * ot, int pos_left, int pos_right) {
	long delta_pos_left, delta_pos_right;
	float delta_left, delta_right, delta_theta, theta2;
	float delta_x, delta_y;

	delta_pos_left = pos_left - ot->state.pos_left_prev;
	delta_pos_right = pos_right - ot->state.pos_right_prev;
	delta_left = delta_pos_left * ot->configuration.wheel_conversion_left;
	delta_right = delta_pos_right * ot->configuration.wheel_conversion_right;
	delta_theta = (delta_right - delta_left) / ot->configuration.wheel_distance;
	theta2 = ot->result.theta + delta_theta * 0.5;
	delta_x = (delta_left + delta_right) * 0.5 * cosf(theta2);
	delta_y = (delta_left + delta_right) * 0.5 * sinf(theta2);

	ot->result.x += delta_x;
	ot->result.y += delta_y;
	ot->result.theta += delta_theta;
  if (ot->result.theta > PI) ot->result.theta -= 2*PI;
  if (ot->result.theta < -PI) ot->result.theta += 2*PI;
	ot->state.pos_left_prev = pos_left;
	ot->state.pos_right_prev = pos_right;
}
